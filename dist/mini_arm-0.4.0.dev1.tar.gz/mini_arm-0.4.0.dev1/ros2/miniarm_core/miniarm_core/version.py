"""Version information for Mini-Arm package."""

__version__ = '0.4.0.dev1'
__author__ = 'Jonathan Shulgach'
